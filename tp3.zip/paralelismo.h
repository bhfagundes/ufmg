#ifndef PARALELISMO_H_
#define PARALELISMO_H_
int maximo (int a, int b);
int max_soma(int* c, int n); 
void* encontrar_somas(void* arg);
#endif 
	
