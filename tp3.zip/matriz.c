#include <stdlib.h>
#include <stdio.h>
#include "matriz.h"

void Valida_matriz(int *m, int *n)
{
	int auxiliar;
	if (*n == 1)
	{
		auxiliar = *m;
		*m = *n;
		*n = auxiliar;
	}
}
void Desalocar_matriz(int m, int **c)
{
	int i;
	for (i =0; i<m;i++)
	{
		free(c[i]);
		c[i]=NULL;
	}
	free(c);
	c=NULL;
}
void Le_matriz(int m, int n, int **g)
{
	int i;
	int j;
	for (i=0; i <m ; i++)
	{
		for (j=0; j < n;j++)
		{
			scanf("%d",&g[i][j]);
		}
	}
}
int** Alocar_matriz(int m, int n)
{
	int i;
	int **c;
	c = (int**)malloc(m * sizeof(int*));
	for(i=0; i < m; i++)
	{
		 c[i] = (int *)malloc(n * sizeof(int));
	}
	return c;
}

