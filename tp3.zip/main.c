#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <pthread.h>
#include "paralelismo.h"
#include "mapa.h"
#include "matriz.h"
#include <time.h>
int main(int argc, char *argv[])
{
	if(argc < 1)
	{
		return 0;
	}
	char *entrada= argv[1];
	int numero_threads=atoi(entrada);
	int m,n,i,j;
	//criei e aloquei  o vetor de mapa
	pthread_t threads[numero_threads];
	scanf ("%d %d",&m,&n);
	//validando se trata de um vetor coluna, caso seja, transforma em vetor linha
	Valida_matriz(&m,&n);	
	int **matriz =Alocar_matriz(m,n);
	Le_matriz(m,n,matriz);
	Mapa **mapa = Alocar_mapa(numero_threads);
	Limite(numero_threads,m,n,mapa);
	Preenche_mapa(numero_threads,mapa,matriz,n);
	for(i=0;i < numero_threads; i++)
	{
		pthread_create(&(threads[i]), NULL, encontrar_somas,(void*)mapa[i]);			
	}
	
	for(i=0;i < numero_threads; i++)
	{
		pthread_join(threads[i],NULL); 		
	}
	int solucao[m];
	for(i=0;i < numero_threads; i++)
	{
		for(j=0;j < mapa[i]->m; j++)
		{
			solucao[(i*(m/numero_threads))+j] = mapa[i]->somas[j]; 		
		}
		
	}
	printf("%d\n",max_soma(solucao,m));
	//Desalocação da memoria
	Desalocar_mapa(numero_threads,mapa);
	Desalocar_matriz(m,matriz);
	return 0;

}
