#ifndef MATRIZ_H_
#define MATRIZ_H_
void Valida_matriz(int *m, int *n);
void Desalocar_matriz(int m, int **c);
void Le_matriz(int m, int n, int **g);
int** Alocar_matriz(int m, int n);
#endif 
	
