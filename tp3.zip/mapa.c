#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include "matriz.h"
#include "mapa.h"
Mapa **Alocar_mapa(int numero_threads)
{
	int i;
	Mapa **mapa = malloc(sizeof(Mapa*) * numero_threads);	
	for(i=0; i< numero_threads;i++)
	{
		mapa[i] = malloc(sizeof(Mapa));
	}
	return mapa;
}
void Limite(int numero_threads, int m, int n, Mapa **mapa)
{
	int i=0;
	int aux_threads;
	if(numero_threads == 1)
	{
		mapa[i]->m = m;
		mapa[i]->n = n;
		mapa[i]->matriz = Alocar_matriz(mapa[i]->m, mapa[i]->n);
		mapa[i]->somas = malloc(sizeof(int) *m);
		mapa[i]->inicio =0;
		mapa[i]->fim = m;

	}
	else
	{
		for (i=0; i< numero_threads; i++)
		{		
			if(m>1)
			{
				aux_threads =numero_threads;
			}
			else
			{
				aux_threads=1;
			}
			mapa[i]->n = n;
			mapa[i]->inicio = i* ceil(m/aux_threads);
			mapa[i]->fim = i*aux_threads +aux_threads;
			if(((m%aux_threads) !=0 && i == aux_threads-1) || mapa[i]->fim > m)
			{
				mapa[i]->fim = m;
			}
			mapa[i]->m=mapa[i]->fim - mapa[i]->inicio;
			mapa[i]->matriz = Alocar_matriz(mapa[i]->m, mapa[i]->n);
			mapa[i]->somas = malloc(sizeof(int) *m);
		}
	}
}
void Preenche_mapa(int numero_threads,Mapa **mapa, int **matriz, int n)
{
	int i,j,k;
	for(i=0; i< numero_threads;i++)
		{
			for(j=mapa[i]->inicio; j < mapa[i]->fim; j++)
			{
				for(k=0; k <n; k++)
				{
					mapa[i]->matriz[j - mapa[i]->inicio][k] = matriz[j][k];
				}
			}
		}
}
void Desalocar_mapa(int numero_threads, Mapa **mapa)
{
	int i;
	for(i=0; i< numero_threads;i++)
	{
		Desalocar_matriz(mapa[i]->m,mapa[i]->matriz);
		free(mapa[i]->somas);	
		free(mapa[i]);
		mapa[i]=NULL;	
	}
		free(mapa);
}
