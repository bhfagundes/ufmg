#ifndef MAPA_H_
#define MAPA_H_
typedef struct 
{ 
	int inicio;
	int fim;
	int m;
	int n;
	int** matriz;
	int* somas; 
	int indice;
} Mapa;
Mapa** Alocar_mapa(int numero_threads);
void Limite(int numero_threads, int m, int n, Mapa **mapa);
void Preenche_mapa(int numero_threads,Mapa **mapa, int **matriz, int n);
void Desalocar_mapa(int numero_threads, Mapa **mapa);
#endif 
