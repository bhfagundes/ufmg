#include "paralelismo.h"
#include "mapa.h"
#include <stdlib.h>
int maximo (int a, int b)
{
	if (a > b)
	{
		return a;
	}	
	return b;
}
int max_soma(int* c, int n) 
{
	int dp[n+2]; 
	dp[n] = dp[n + 1] = 0;
	for (int i = n - 1; i >= 0; --i)
	{
		dp[i] = maximo(c[i] + dp[i + 2], dp[i + 1]);
	}	
	return dp[0];
}
void* encontrar_somas(void* arg)
{
	int i;
	Mapa *index =  arg;  // Conversão do parametro da função, que indica o número da thread.			
	for(i=0; i<index->m; i++ )
    {
		index->somas[i]=max_soma(index->matriz[i],index->n);	
	}
	return NULL;
}	

