Conteudo** Alocar_Labirinto(int n,int m);
/*
Nome: alocar labirinto
Fun��o: alocar a memoria necessaria paar uma matriz de labirinto de tamano n*m
Sa�da: matriz m*n alocada
*/
void Desalocar_Labirinto(int n, Conteudo **c);
/*
Nome: desalocarlabirinto
Fun��o: desaloca a memoria gasta na matriz
Sa�da: apenas desaloca a memoria
*/
int Buscar_Labirinto(Conteudo c,Conteudo **g,int n, int m);
/*
Nome: buscaLabirinto
Fun��o: buscar as coordenadas especificas de um dado valor
Sa�da: inteiro correspondente a posicao
*/
void Le_Labirinto(int n, int m, Conteudo** g);
/*
Nome: leLabirinto
Fun��o: recebe os valores de cada posicao do labirinto
Sa�da: apenas preenche a matriz
*/
Conteudo** Copia(int n, int m,Conteudo** l);
/*
Nome: Copia
Fun��o: cria uma copia do labirinto recebido
Sa�da: um labirinto identico ao recebido
*/
