#ifndef STACK_H_
#define STACK_H_

// Tipo dos elementos na pilha.
typedef int StackType;

// Tipo de dado stack (Pilha).
// Para garantir o ecapsulamento, 'struct StackStruct' só é definido em stack.c.
typedef struct StackStruct* stack;

// Cria uma pilha vazia.
stack new_stack();

// Testa se a pilha está vazia.
int empty_stack(stack s);

// Retorna o número de elementos na pilha.
int size_stack(stack s);

// Retorna o elemento que está no topo da pilha.
// Precondição: a pilha não pode estar vazia.
StackType top_stack(stack s);

// Insere k no topo da pilha.
void push_stack(StackType k, stack s);

// Remove o elemento que está no topo da pilha.
// Precondição: a pilha não pode estar vazia.
void pop_stack(stack s);

// Faz a pilha s ficar igual a p.
void copy_stack(stack s, stack p);

// Troca o conteúdo da pilha s com o da pilha p.
void swap_stack(stack s, stack p);

// Libera a memória alocada para a pilha.
void delete_stack(stack s);

#endif  // STACK_H_
