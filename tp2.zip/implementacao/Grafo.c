#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Grafo.h" //inclui os Prot�tipos
#include "labirinto.h"
#include "queue.h"
#include "stack.h"
//Defini��o do tipo Grafo
struct grafo
{
    int nro_vertices;
    int grau_max;
    int** arestas;
    int* grau;
    int nro_chave;
    Conteudo *chaves;
	int chave_ocupada;
};

Grafo* cria_Grafo(int nro_vertices, int grau_max, int nro_chave)
{
    Grafo *g;
    g = (Grafo*) malloc(sizeof(struct grafo));
    if(g != NULL)
    {
        //Alocando a memoria gasta pela estrutura e setando os parametros do grafo
        int i;
        g->nro_vertices = nro_vertices;
        g->grau_max = grau_max;
        g->grau = (int*) calloc(nro_vertices,sizeof(int));
        g->arestas = (int**) malloc(nro_vertices * sizeof(int*));
		g->nro_chave = nro_chave;
		g->chave_ocupada=0;
		g->chaves= (Conteudo*) malloc(nro_chave * sizeof(Conteudo));
        for(i=0; i<nro_vertices; i++)
		{
            g->arestas[i] = (int*) malloc(grau_max * sizeof(int));
		}
    }
    return g;
}
void libera_Grafo(Grafo* gr)
{
    if(gr != NULL)
    {
        int i;
        //percorrendo a estrutura para desaloca-la
        for(i=0; i<gr->nro_vertices; i++)
		{
            free(gr->arestas[i]);
		}
		free(gr->arestas);
        free(gr->grau);
        free(gr->chaves);
        free(gr);
    }
}

int insereAresta(Grafo* gr, int orig, int dest)
{
    //verifica se o grafo exista
    if(gr == NULL)
    {
        return 0;
    }
    //verifica os limites do grafo
    if(orig < 0 || orig >= gr->nro_vertices)
    {
        return 0;
    }
    if(dest < 0 || dest >= gr->nro_vertices)
    {
        return 0;
    }
    //insere a aresta na posicao correta
    gr->arestas[orig][gr->grau[orig]] = dest;
    gr->grau[orig]++;
    return 1;
}

int removeAresta(Grafo* gr, int orig, int dest)
{
    //verifica se o grafo exista
    if(gr == NULL)
    {
        return 0;
    }
    //verifica os limites do grafo
    if(orig < 0 || orig >= gr->nro_vertices)
    {
        return 0;
    }
    if(dest < 0 || dest >= gr->nro_vertices)
    {
        return 0;
    }
    int i = 0;
    //percorrendo a estrutura para encontrar onde esta a aresta
    while(i<gr->grau[orig] && gr->arestas[orig][i] != dest)
	{
        i++;
	}
	if(i == gr->grau[orig])
	{
        return 0;
	}
	//decrementando o grau do vertice e excluindo a aresta
    gr->grau[orig]--;
    gr->arestas[orig][i] = gr->arestas[orig][gr->grau[orig]];
    return 1;
}
int Existe_Chave(Grafo *g, Conteudo c)
{
	int i=0;
	//percorre toda a estrutura de chave ate o numero de chaves verificando se existe a chave
	for (i=0; i < g->chave_ocupada; i++)
	{
		if (strcmp(g->chaves[i],c)==0)
		{
			return 1;
		}
	}
	return 0;
}
void imprime_Grafo(Grafo *gr)
{
    if(gr == NULL)
	{
        return;
	}
    int i, j;
    //imprime a lista de adjacencia do grafo
    for(i=0; i < gr->nro_vertices; i++)
	{
        printf("%d: ", i);
        for(j=0; j < gr->grau[i]; j++)
		{
        	printf("%d, ", gr->arestas[i][j]);
        }
        printf("\n");
    }
}
int verificaVizinho(int n,int m,Conteudo **labirinto,int y, int x)
{
    //verifica limites de y
	if (n <=y)
	{
		return  0;
	}
	//verifica limites de x
	if (m <= x)
	{
		return 0;
	}
	//verifica limites de y
	if(y<0)
	{
		return 0;
	}
	//verifica limites de x
	if (x < 0)
	{
		return 0;
	}
    //verifica conteudo da posicao
	if(strcmp(labirinto[y][x],"#") ==0)
	{
		return 0;
	}
	return 1;
}
void Constroi(Conteudo **labirinto, Grafo *g, int n, int m)
{
	int i;
	int j;
	int x;
	int y;
	int tam;
	int auxiliar;
	//loop para varrer a matriz
	for (i=0; i<n;i++)
	{
		for (j=0; j<m; j++)
		{
			if (strcmp(labirinto[i][j],"#") !=0)
			{
			    //tratando o buraco de minhoca
				if (strlen(labirinto[i][j]) >1)
				{
					tam=strlen(labirinto[i][j]);
					sscanf(labirinto[i][j],"%d",&auxiliar);
					//quebrando o valor da casa em inteiros x e y
					y=auxiliar/ pow(10,tam-1);
					x=auxiliar%10;
					//indexando a posicao e inserindo
					insereAresta(g,i*m+j,y*m+x);
				}
				//verificando o vizinho acima
				if (verificaVizinho(n,m,labirinto, i+1,j) ==1)
				{
						insereAresta(g,i*m +j,(i+1)*m +j);
				}
				//verificando vizinho abaixo
				if (verificaVizinho(n,m,labirinto, i-1,j) ==1)
				{
						insereAresta(g,i*m +j,((i-1)*m +j));
				}
				//verificando vizinho a direita
				if (verificaVizinho(n,m,labirinto, i,j+1) ==1)
				{
						insereAresta(g,i*m +j,(i*m +(j+1)));
				}
				//verificando vizinho a esquerda
				if (verificaVizinho(n,m,labirinto, i,j-1) ==1)
				{
						insereAresta(g,i*m +j,(i*m +(j-1)));
				}
			}
		}
	}
}
int buscaLargura_Grafo(Grafo *gr, int ini, int *visitados,Conteudo** labirinto, int n, int m, int t,stack s)
{
	int origem =ini;
	int destino =Buscar_Labirinto("E",labirinto,n, m);
	int atual;
	int x;
	int y;
	int tam;
	int j;
	int auxiliar;
    int i;
    //criando fila de prioridades
    queue  q=new_queue();
    //zerando o vetor
    for(i=0; i<gr->nro_vertices; i++)
    {
        visitados[i] = 0;
	}
	//inserindo posicao de origem na fila
	push(origem,q);
	//loop executado enquanto fila conter elementos
	while(!empty(q) )
	{
	    //pega o elemento da frente
		atual =front(q);
        //remove elemento da frente
		pop(q);
		//verifica se esta na posicao adequada
		if(atual == destino)
		{
			push_stack(atual,s);
			delete_queue(q);
			return 1;
		}
		//insere na pilha caso nao tenha visitado este vertices
		if (visitados[atual]==0)
		{
			push_stack(atual,s);
		}
		//seta vertice como visitado
		visitados[atual]++;
		//verifica adjacentes
		for(j=0; j < gr->grau[atual]; j++)
		{
		    //verifica adjacentes nao visitados
        	if(visitados[gr->arestas[atual][j]] == 0)
        	{
        	    //transforma o numero do vertice em coordenadas y e x
				y= gr->arestas[atual][j]/m;
				x= gr->arestas[atual][j] %m ;
				//verifica o conteudo da posicao no labirinto
        		if(strcmp(labirinto[y][x],".")==0)
        		{
        		    //insere vertice na fila
        			push(gr->arestas[atual][j],q);
        		}
        		else if(strcmp(labirinto[y][x],"C")==0)
        		{
        		    //verifica se existe chave para a porta
        			if(Existe_Chave(gr,"c")==1)
					{
        				push(gr->arestas[atual][j],q);
					}
        		}
				else if(strcmp(labirinto[y][x],"D")==0)
        		{
        		    //verifica se existe chave para a porta
        			if(Existe_Chave(gr,"d")==1)
					{
        				push(gr->arestas[atual][j],q);
					}
        		}
				else if(strcmp(labirinto[y][x],"H")==0)
        		{
        		    //verifica se existe chave para a porta
        			if(Existe_Chave(gr,"h")==1)
					{
        				push(gr->arestas[atual][j],q);
					}
        		}
				else if(strcmp(labirinto[y][x],"S")==0)
        		{
        		    //verifica se existe chave para a porta
        			if(Existe_Chave(gr,"s")==1)
					{
        				push(gr->arestas[atual][j],q);
					}
        		}
				else if(strcmp(labirinto[y][x],"c")==0)
        		{
        		    //verifica se ja foi atingido o maximo de chaves
        			if(gr->nro_chave > gr->chave_ocupada)
					{
					    //pega a chave
						strcpy(gr->chaves[gr->chave_ocupada],labirinto[y][x]);
						gr->chave_ocupada++;
						//aloca elementos gastos na busca em largura
						int aux[m*n];
						Conteudo **labirinto_aux = Copia(n,m,labirinto);
						stack laux = new_stack();
						//verifica se pegar a chave leva a saida valida
						if(buscaLargura_Grafo(gr, atual, aux,labirinto_aux, n, m,t,laux ) ==-1)
						{
						    //caso nao leve, remove a chave
							gr->chave_ocupada--;
						}
						//liberando memoria gasta
						delete_stack(laux);
						Desalocar_Labirinto(n, labirinto_aux);

					}
        			push(gr->arestas[atual][j],q);
        		}
				else if(strcmp(labirinto[y][x],"d")==0)
        		{
        			 //verifica se ja foi atingido o maximo de chaves
        			if(gr->nro_chave > gr->chave_ocupada)
					{
					    //pega a chave
						strcpy(gr->chaves[gr->chave_ocupada],labirinto[y][x]);
						gr->chave_ocupada++;
						//aloca elementos gastos na busca em largura
						int aux[m*n];
						Conteudo **labirinto_aux = Copia(n,m,labirinto);
						stack laux = new_stack();
						//verifica se pegar a chave leva a saida valida
						if(buscaLargura_Grafo(gr, atual, aux,labirinto_aux, n, m,t,laux ) ==-1)
						{
						    //caso nao leve, remove a chave
							gr->chave_ocupada--;
						}
						//liberando memoria gasta
						delete_stack(laux);
						Desalocar_Labirinto(n, labirinto_aux);

					}
        			push(gr->arestas[atual][j],q);
        		}
				else if(strcmp(labirinto[y][x],"h")==0)
        		{

        			 //verifica se ja foi atingido o maximo de chaves
        			if(gr->nro_chave > gr->chave_ocupada)
					{
					    //pega a chave
						strcpy(gr->chaves[gr->chave_ocupada],labirinto[y][x]);
						gr->chave_ocupada++;
						//aloca elementos gastos na busca em largura
						int aux[m*n];
						Conteudo **labirinto_aux = Copia(n,m,labirinto);
						stack laux = new_stack();
						//verifica se pegar a chave leva a saida valida
						if(buscaLargura_Grafo(gr, atual, aux,labirinto_aux, n, m,t,laux ) ==-1)
						{
						    //caso nao leve, remove a chave
							gr->chave_ocupada--;
						}
						//liberando memoria gasta
						delete_stack(laux);
						Desalocar_Labirinto(n, labirinto_aux);

					}
        			push(gr->arestas[atual][j],q);
        		}
				else if(strcmp(labirinto[y][x],"s")==0)
        		{
        			 //verifica se ja foi atingido o maximo de chaves
        			if(gr->nro_chave > gr->chave_ocupada)
					{
					    //pega a chave
						strcpy(gr->chaves[gr->chave_ocupada],labirinto[y][x]);
						gr->chave_ocupada++;
						//aloca elementos gastos na busca em largura
						int aux[m*n];
						Conteudo **labirinto_aux = Copia(n,m,labirinto);
						stack laux = new_stack();
						//verifica se pegar a chave leva a saida valida
						if(buscaLargura_Grafo(gr, atual, aux,labirinto_aux, n, m,t,laux ) ==-1)
						{
						    //caso nao leve, remove a chave
							gr->chave_ocupada--;
						}
						//liberando memoria gasta
						delete_stack(laux);
						Desalocar_Labirinto(n, labirinto_aux);

					}
        			push(gr->arestas[atual][j],q);
        		}
        		//verifica se e a saida
				else if(strcmp(labirinto[y][x],"E")==0)
        		{
        			push(gr->arestas[atual][j],q);
        		}
        		//verifica se e buraco de minhoca
				else if(strlen(labirinto[y][x]) >1)
        		{
        		    //quebra o buraco de minhoca em coordenadas
					tam=strlen(labirinto[y][x]);
					sscanf(labirinto[y][x],"%d",&auxiliar);
					strcpy(labirinto[y][x],".");
					y=auxiliar/ pow(10,tam-1);
					x=auxiliar%10;
					for(i=0;i<gr->nro_vertices;i++)
					{
						visitados[i]=0;
					}
					push(y*m+x,q);
					push_stack(gr->arestas[atual][j],s);
        		}

        	}
        }

	}
	//desaloca fila
	delete_queue(q);
	return-1;
}
int procuraMenorDistancia(int *dist, int *visitado, int NV)
{
    int i, menor = -1, primeiro = 1;
    //varre o vetor procurando o menor
    for(i=0; i < NV; i++)
	{
        if(dist[i] >= 0 && visitado[i] == 0)
		{
            if(primeiro)
			{
                menor = i;
                primeiro = 0;
            }
			else
			{
                if(dist[menor] > dist[i])
				{
                    menor = i;
				}
			}
        }
    }
    return menor;
}

void menorCaminho_Grafo(Grafo *gr, int ini, int *ant, int *dist)
{
    int i, cont, NV, ind, *visitado, vert;
    cont = NV = gr->nro_vertices;
    visitado = (int*) malloc(NV * sizeof(int));
    for(i=0; i < NV; i++)
	{
        ant[i] = -1;
        dist[i] = -1;
        visitado[i] = 0;
    }
    dist[ini] = 0;
    //procurando o menor caminho
    while(cont > 0)
	{
        vert = procuraMenorDistancia(dist, visitado, NV);
        if(vert == -1)
            break;
        visitado[vert] = 1;
        cont--;
        for(i=0; i<gr->grau[vert]; i++)
		{
            ind = gr->arestas[vert][i];
            if(dist[ind] < 0)
			{
               dist[ind] = dist[vert] + 1;
               ant[ind] = vert;
            }
			else
			{
                if(dist[ind] > dist[vert] + 1)
				{
                    dist[ind] = dist[vert] + 1;
                    ant[ind] = vert;
                }
            }
        }
    }

    free(visitado);
}
