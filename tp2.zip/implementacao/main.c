#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Grafo.h"
#include "labirinto.h"
int main()
{
	int n,m,t;
	//recebendo valores das dimensoes do labirinto e maximo de chaves
	scanf("%d %d %d", &n,&m,&t);
	int ini;
	int visitado[n*m];
	int distancia=0;
	//alocando memoria para grafo
	Grafo *g =cria_Grafo(n*m, 5,t);
	//alocando memoria para labirinto
	Conteudo** labirinto = Alocar_Labirinto(n,m);
	//lendo conteudo do labirinto
	Le_Labirinto(n,m,labirinto);
	//constroi grafo atraves do labirinto
	Constroi(labirinto,g,n,m);
	//procura coordenada inicial
	ini = Buscar_Labirinto("V",labirinto,n, m);
	//aloca memoria para pilha
	stack s=new_stack();
	//cria copia do labirinto para usar em funcoes
	Conteudo** labirinto_aux=Copia(n,m,labirinto);
	//verifica se existe caminho
	int resultado = buscaLargura_Grafo(g, ini,visitado,labirinto_aux,n,m,t,s);
	if( resultado == -1)
	{
	    //como nao existe caminho e setado valor -1
		distancia= -1;
	}
	else
	{
	    //este trecho e o chamado produz solucao
	    //caso exista caminho, aloca as variaveis necessarias
		int dist[n*m];
		int aux;
		//pega o elemento do topo da pilha
		aux = top_stack(s);
		//remove elemento do topo da pilha
		pop_stack(s);
		//laco executa enquanto pilha nao esta vazia
		while (!empty_stack(s))
		{
		    //procura o menor caminho entre o elemento do topo da pilha e os demais
			menorCaminho_Grafo(g,top_stack(s),visitado,dist);
			//verifica se o caminho dos dois elementos adjacente e 1
			if(dist[aux] == 1 )
			{
			    //verifica se esta em um buraco de minhoca
				if(strlen(labirinto[top_stack(s)/m][top_stack(s)%m])<2)
				{
				    //incrementa caso nao esteja
					distancia++;
				}
				else
				{
				    //apos passar por buraco de minhoca, atribui a posicao como '.'
					strcpy(labirinto[top_stack(s)/m][top_stack(s)%m],".");
				}
				aux =top_stack(s);
			}
			pop_stack(s);
		}
	}
	//printa o menor caminho ou -1
	printf("%d\n",distancia);
	//desaloca as estruturas
	delete_stack(s);
	Desalocar_Labirinto(n,labirinto);
	Desalocar_Labirinto(n,labirinto_aux);
	libera_Grafo(g);
	return  0;
}
