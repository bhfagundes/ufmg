#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "Grafo.h"
Conteudo** Alocar_Labirinto(int n, int m)
{
	int i,j;
	//alocando o conteudo e preenchendo com vazio
	Conteudo **c;
	c = malloc(n * sizeof(Conteudo*));
	for(i=0; i < n; i++)
	{
		c[i] = malloc(m * sizeof(Conteudo));
		for (j = 0; j < m; j++)
		{
            		strcpy(c[i][j],"\0");
       		}
	}
	return c;
}
void Desalocar_Labirinto(int n, Conteudo **c)
{
	int i;
	//desalocando a memoria
	for (i =0; i<n;i++)
	{
		free(c[i]);
		c[i]=NULL;
	}
	free(c);
	c=NULL;

}
int Buscar_Labirinto(Conteudo c,Conteudo **g,int n, int m)
{
	int i=0;
	int j=0;
	int v;
	//varre a matriz procurando uma dada coordenada
	for(i =0; i < n; i++)
	{
		for (j=0; j< m; j++)
		{

			if (strcmp(c,g[i][j]) == 0)
			{
				v = (i*m) + j;
				return v;
			}
		}
	}
	return -1;
}
void Le_Labirinto(int n, int m, Conteudo **g)
{
	int i;
	int j;
	//recebe os valores do labirinto
	for (i=n-1; i >= 0; i--)
	{
		for (j=0; j < m;j++)
		{
			scanf("%s",g[i][j]);
		}
	}
}
Conteudo** Copia(int n, int m,Conteudo** l)
{
    //aloca nova matriz
	Conteudo **aux = Alocar_Labirinto(n,m);
	int i,j;
	//realiza a copia de conteudo
	for(i=0; i < n;i++)
	{
		for(j=0; j <m; j++)
		{
			strcpy(aux[i][j],l[i][j]);
		}
	}
	return aux;

}
