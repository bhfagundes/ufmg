//Arquivo Grafo.h
#include "queue.h"
#include "stack.h"
typedef char Conteudo[5];
typedef struct grafo Grafo;

Grafo* cria_Grafo(int nro_vertices, int grau_max, int nro_chave);
/*
Nome: Cria Grafo
Fun��o: Alocar a mem�ria gasta para um grafo dado um n�mero de v�rtices
Sa�da: Um Tad Grafo
*/
void libera_Grafo(Grafo* gr);
/*
Nome: Libera Grafo
Fun��o: liberar a mem�ria gasta pelo tad grafo
Sa�da: apenas libera a mem�ria
*/
int insereAresta(Grafo* gr, int orig, int dest);
/*
Nome: insere aresta
Fun��o: inserir uma aresta no grafo entre dois vertices dados
Sa�da: inteiro 1 caso de sucesso ou 0 de falha
*/
int removeAresta(Grafo* gr, int orig, int dest);
/*
Nome: remove aresta
Fun��o: remover uma aresta no grafo entre dois vertices dados
Sa�da: inteiro 1 caso de sucesso ou 0 de falha
*/
int Existe_Chave(Grafo *g, Conteudo c);
/*
Nome: existe chave
Fun��o: verificar se a estrutura armazena uma dada chave
Sa�da: inteiro 1 caso de sucesso ou 0 de falha
*/
void Constroi(Conteudo **labirinto, Grafo *g, int n, int m);
/*
Nome: constroi
Fun��o: atraves do labirinto dado, e montado um grafo por listas de adjacencias
Sa�da: apenas preenche a estrutura grafo
*/
int buscaLargura_Grafo(Grafo *gr, int ini, int *visitados,Conteudo** labirinto, int n, int m, int t,stack s);
/*
Nome: buscaLargura
Fun��o: verificar a existencia de caminhos entre vertice inicial e final
Sa�da: pilha contendo vertices visitados, 1 caso de existir caminho, -1 caso nao exista
*/
void menorCaminho_Grafo(Grafo *gr, int ini, int *antecessor, int *distancia);
/*
Nome: menor caminho
Fun��o: encontrar a menor distancia entre um vertice e todos os demais
Sa�da: vetor de distancias
*/
int verificaVizinho(int n,int m,Conteudo **labirinto, int y, int x);
/*
Nome: verificavizinho
Fun��o: funcao utilizada na construcao do grafo para verificar as adjacencias de uma coordenada
Sa�da: retorna 1 caso posicao seja valida, 0 caso seja invalida
*/
void imprime_Grafo(Grafo *gr);
/*
Nome: imprimeGrafo
Fun��o: imprimir o grafo atual, funcao utilizada para debugar
Sa�da: e exibido na tela o grafo
*/
int procuraMenorDistancia(int *dist, int *visitado, int NV);
/*
Nome: procuraMenorDistancia
Fun��o: funcao auxiliar para menor caminho
Sa�da: retorna a menor distancia entre vertices
*/
