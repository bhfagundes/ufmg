#include "biblioteca.h"
#include<stdlib.h>
#include<stdio.h>
#include <string.h>
int Comparar(const void *a, const void *b) 
{ 
    Livro *ia = (Livro*)a;
    Livro *ib = (Livro *)b;
    return strcmp(ia->titulo, ib->titulo);
}
int Quantidade(int m, int n)
{
	int qtd;
	if (n%m == 0)
	{
		qtd=n/m;
	}
	else
	{
		qtd=n/m+1;
	}
	return qtd;
} 
void Menor(Arquivos arq,Livro *livro)
{
	FILE *arquivo;
	arquivo = fopen(arq.Nome, "r");
	int contador=0;
	int limite = arq.max;
	int parada = arq.pos;
	Livro comparar;
	if(limite == parada)
	{
		strcpy(livro->titulo,"~");
	}
	else
	{
		for(contador=0; contador < limite;contador++)
		{
			fscanf(arquivo,"%s %c", livro->titulo, &livro->disponivel);
			if (contador == parada)
			{
				contador = limite;		
			}	
		}
		
	}
	fclose(arquivo);
	
}
void Remover_arquivos(int qtd)
{
	int i;
	char nome[qtd][20];
	for (i=0; i < qtd;i++)
	{
		sprintf(nome[i],"%d",i);
		remove(nome[i]);
	}
}
void Gerar_Indice(char *nome, int e, int l, Livro *comparar)
{
	FILE *f = fopen(nome,"r");
	int contagem_livros;
	int flag=0;
	int n_estante=0;
	int contador=0;
	int n_linhas=0;
	Titulo t;	
	FILE *estante=fopen("indice","w");
	while (!feof(f))
	{
		fscanf(f,"%s %c[^\n]", comparar->titulo, &comparar->disponivel);
		if( contador==0)
		{
			fprintf(estante,"%s ",comparar->titulo);
			n_linhas++;			
			contador++;
		}
		else if(contador == l-1 && contador != 0)
		{
			fprintf(estante,"%s\n",comparar->titulo);
			contador =0;
		}
		else
		{
			contador++;
		}
		flag++;
	}
	if (contador !=0)
	{
		fprintf(estante,"%s\n",comparar->titulo);
		contador++;
	}

	strcpy(comparar->titulo, "#");
	comparar->disponivel = '\0';	
	while (n_linhas < e)
	{
		fprintf(estante,"#\n");
		n_linhas++;
	}		
	
	fclose(estante);
	fclose(f);
}
void Gerar_Binarios(char *nome, int e, int l, Livro *comparar, int n)
{
	FILE *f = fopen(nome,"r");
	int contagem_livros;
	int flag=0;
	int n_estante=0;
	int contador=0;
	Titulo t;	
	FILE *estante=NULL;
	int i;
	for (i=0; i < 51; i++)
	{
		comparar->titulo[i] = '\0';
	}
	while (flag < n)
	{		
		fscanf(f,"%s %c[^\n]", comparar->titulo, &comparar->disponivel);						
		if (flag == 0)
		{
			sprintf(t,"estante%d",n_estante);
			estante = fopen(t, "wb");
			fwrite(comparar->titulo,sizeof(comparar->titulo),1,estante);
			fwrite(&comparar->disponivel,sizeof(comparar->disponivel),1,estante);
			n_estante++;
		}
		else if(flag % l ==0)
		{
			fclose(estante);
			if ( flag < n-1)
			{
				sprintf(t,"estante%d",n_estante);
				estante = fopen(t, "wb");
				n_estante++;
				fwrite(comparar->titulo,sizeof(comparar->titulo),1,estante);
				fwrite(&comparar->disponivel,sizeof(comparar->disponivel),1,estante);
			}
			
		}
		else
		{
			fwrite(comparar->titulo,sizeof(comparar->titulo),1,estante);
			fwrite(&comparar->disponivel,sizeof(comparar->disponivel),1,estante);
		}
		flag++;
				
	
	}
	fclose(f);
	fclose(estante);
}
int Busca_Indice(Titulo t)
{
	Titulo inicial, final;
	int linha=0;
	FILE *indice = fopen ("indice","r");
	while (!feof(indice))
	{
		fscanf(indice,"%s %s", inicial, final);
		if (strcmp(t,inicial) >=0)
		{
			if(strcmp(t,final) <=0)
			{
				fclose(indice);
				return linha;
			}		
		}	
		linha++;
	}
	fclose(indice);
	return -1;
}	
int Busca_Livro(Titulo x,int posicao, char *emprestado)
{
	Titulo nome_estante;
	int e=0;	
	int tamanho_arquivo;
	int m;
	sprintf(nome_estante, "estante%d",posicao);
	FILE *f = fopen(nome_estante,"rb");
	Livro l;
	fseek(f,0,SEEK_END);
	tamanho_arquivo =ftell(f)/sizeof(Livro);
	int d = tamanho_arquivo-1;		
	fseek(f,0 * sizeof(Livro),SEEK_SET);
	while(e <= d)
	{
		m=(e+d)/2;
		fseek(f,m * sizeof(Livro),SEEK_SET);
		fread (&l , sizeof(Livro),1,f) ;		
		if (strcmp(x,l.titulo) == 0)
		{
			fclose(f);
			*emprestado = l.disponivel;
			return m;
		}
		if (strcmp(x,l.titulo) > 0)
		{
			e = m+1;
		}
		else
		{
			d = m-1;
		}
		
	}
	fclose(f);
	return -1;
}
void Ordenar(Arquivos *f, int qtd, int n)
{
	Livro menor, comparar;
	int i, contador=0,indice=0;
	FILE *final;
	final = fopen("livros_ordenados","w");	
	/*itera n vezes para obtermos n livro*/	
	while(contador < n)
	{	
		i =0;
		strcpy(menor.titulo,"~");
		/* o objetivo desta condicao e obter o menor livro*/
		while (i < qtd)
		{
			/* funcao Menor retorna o elemento na posicao correta no arquivo*/
			Menor(f[i],&comparar);		
			if (strcmp(menor.titulo,comparar.titulo ) > 0)
			{
				menor = comparar;
				indice = i;
			}
			i++;
		}
		fprintf(final,"%s %c\n",menor.titulo,menor.disponivel);
		/*incrementa a posicao inicial para determinar que ja lemos mais um registro do arquivo*/		
		f[indice].pos++;
		contador++;	
	}
	fclose(final);

}
