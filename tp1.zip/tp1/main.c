#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "biblioteca.h"
int main()
{
	int m,n,e,l,k;
	scanf("%d %d %d %d %d", &n,&m,&e,&l,&k);
	Livro *livro = (Livro*) malloc(m * sizeof(Livro));
	int i;
	FILE *divididos;
	int flag=0;
	int qtd,contagem=0,nnome=0;
	qtd=Quantidade(m,n);
	char nome[qtd][20];
	/*Lendo os arquivos e já dividindo em arquivos itera entre os n livros*/ 
	while( flag < n)
	{
		/*como estou criando arquivos de tamanho m, verifica se ja li m livros */
		if (contagem == m)
		{
			qsort(livro,contagem,sizeof(Livro),Comparar);
			sprintf(nome[nnome],"%d",nnome);
			divididos =fopen(nome[nnome], "w");
			/*escreve os livros no arquivo*/
			for (i=0; i < contagem; i++)
			{
				fprintf(divididos,"%s %c\n", livro[i].titulo,livro[i].disponivel);
			}
			contagem =0;
			nnome++;
			fclose(divididos);
		}
		scanf("%s %c", livro[contagem].titulo, &livro[contagem].disponivel);
		contagem++;
		flag++;
	}
	/*verifica se a divisao n/m foi exata, caso nao tenha sido salva o restante dos livros*/
	if (contagem >0)
	{
		/*funcao qsort e usada para salva m livros ja ordenados */
		qsort(livro,contagem,sizeof(Livro),Comparar);
		sprintf(nome[nnome],"%d",nnome);
		divididos =fopen(nome[nnome], "w");
		for (i=0; i < contagem; i++)
		{
			fprintf(divididos,"%s %c\n", livro[i].titulo,livro[i].disponivel);
		}
		fclose(divididos);
	}
	/*libera a memoria gasta pelos 3 livros para poder ordenação final*/
	free(livro);
	/*cria as estrutura para ordenação final*/
	Arquivos f[qtd];
	/*copia o nome dos arquivos para poder abri-lo*/
	for (i =0; i < qtd; i++)
	{
		strcpy(f[i].Nome, nome[i]);
		f[i].pos =0;
		f[i].max = m;
	}
	/*caso a divisao n/m nao seja exata, e setado o resto da divisao como posicao maxima no ultimo arquivo*/
	if(n%m !=0)
	{
		f[qtd-1].max = contagem;
	}
	/*cria arquivo final ordenado*/
	Ordenar(f,qtd,n);
	/* remover os arquivos criados na ordenação*/	
	Remover_arquivos(qtd);
	/*cria variavel para ser usada nas funcoes abaixo*/
	Livro *comparar= malloc(sizeof(Livro));
	Gerar_Indice("livros_ordenados", e,l,comparar);
	Gerar_Binarios("livros_ordenados", e,l,comparar,n);
	/*liberando a memoria da variavel utilizada*/
	free(comparar);
	int pos_estante;
	int pos_livro;
	char emprestado;
	i=0;
	Titulo t;
	strcpy(t,"\0");
	while (i < k)
	{
		scanf("%s",t);
		pos_estante =Busca_Indice(t);
		if (pos_estante != -1)
		{
			pos_livro =Busca_Livro(t,pos_estante,&emprestado);
			if (pos_livro == -1)
			{
				printf("livro nao encontrado\n");
			}	
			else if(emprestado == '0')
			{
				printf("emprestado\n");
			}
			else
			{
				printf("disponivel na posicao %d da estante %d\n",pos_livro,pos_estante);
			}
		}
		else
		{
			printf("Livro nao encontrado\n");
		}
		i++;
	}
	return 0;
}
