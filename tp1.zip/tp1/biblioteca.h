typedef char Titulo[51];
typedef struct livro 
{
	Titulo titulo;
	char disponivel ;
} Livro;
typedef struct arquivos
{
	char Nome[20];
	int pos, max;
}Arquivos;
int Comparar(const void *a, const void *b);
/*
Nome: Comparar
Parametros: Duas strings
Obetivo: funcao auxiliar para ser utilizada pela qsort
Saida: um inteiro resultanta da strcmp entra as duas strings
*/ 
int Quantidade(int m, int n);
/*Nome: Quantidade
Parametros: Dois inteiros
Obetivo: funcao responsavel por retornar o numero de arquivos
que serao necessarios para gravar n livros, onde cada arquivo 
contem m livros
saida: um inteiro correspondente ao numero de arquivos
*/ 
void Menor(Arquivos arq,Livro *livro);
/*Nome: Menor
Parametros: uma estrutura arquivo e um objeto livro
Obetivo: armazenar na variavel livro um dado elemento
saida: nao tem saida, apenas armazena em livro o livro correspondente
a linha desejada que esta armazenada na estrutura arq
*/ 
void Remover_arquivos(int qtd);
/*Nome: Remover_arquivos
Parametros: um inteiro para quantidade
Obetivo: excluir todos os arquivos auxiliares criados
saida: nao tem, apenas exclui os arquivos
*/ 
void Gerar_Indice(char *nome, int e, int l, Livro *comparar);
/*Nome: Gerar_Indice
Parametros: uma string nome, inteiro e, inteiro l e uma estrutura livro
Obetivo: abrir o arquivo com nome da string passada e de acordo com os 
parametros e (numero de estante) e l (numero de livros por estante), criar
um indice, onde em cada linha e escrita o primeiro livro escrito e o ultimo
saida: nao tem, apenas cria um arquivo
*/ 
void Gerar_Binarios(char *nome, int e, int l, Livro *comparar, int n);
/*Nome: Gerar_Binarios
Parametros: uma string nome, inteiro e, inteiro l e uma estrutura livro
Obetivo: abrir o arquivo com nome da string passada e de acordo com os 
parametros e (numero de estante) e l (numero de livros por estante), criar
os arquivos binarios para cada estante
saida: nao tem, apenas cria os arquivos binarios 
*/
int Busca_Indice(Titulo t);
/*Nome: Busca_Indice
Parametros: uma string 
Obetivo: procurar a string recebida no indice, verificando se a mesma esta no
intervalo de valores armazenados no indice em cada linha
saida: retorna um inteiro referente a posicao da estante ou -1 caso o livro nao
esteja nos intervalos das estante 
*/
int Busca_Livro(Titulo x,int posicao, char *emprestado);
/*Nome: Busca_Livro
Parametros: uma string, um inteiro e um char 
Obetivo: procurar a string recebida na estamte de indice posicao e armazenar em
caso de encontrado o estado do livro na variavel emprestado
saida: um inteiro correspondente ao titulo buscado ou -1 caso o livro nao seja
encontrado, tambem e setado o estado atual do livro na variavel emprestado 
*/
void Ordenar(Arquivos *f, int qtd, int n);
/*Nome:Orndenar
Parametros: estruturas arquivos, inteiro quantidade e inteiro n 
Obetivo: Ordenar os arquivos armazenados em f concatenando os mesmo
saida: apenas cria um arquivo ordenado utilizando memoria externa 
*/
