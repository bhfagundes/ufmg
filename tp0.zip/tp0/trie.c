#include "trie.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
No* Cria()
{
	int aux=0;
	No *no= malloc(sizeof(No));
	no->pai = NULL;
	no->tipo = 'I'; 
	for (aux = 0; aux < 26; aux++)
	{
		no->letras[aux] = NULL;
	}
	no->rep = 0;
	return no;
}
No* Fim(No *no, char *palavra)
{
	int i;
    	int index;
	No *aux;
	i = 0;
	No* aux2;
	aux = no;
	if (strcmp(palavra,"\0") == 0)
    	{
		return NULL;
	} 
    	else 
    	{
		
		int tamanho =strlen(palavra); 
		for (i =0; i<tamanho; i++)
		{	
			index = (int)palavra[i] - 97;			
			aux2 =aux->letras[index]; 
			if (aux2 == NULL)
			{
				return NULL;
			}				
			aux = aux->letras[index];		
		}
	}
	if (aux->tipo =='P')
	{	
		return aux;
	}
	return NULL;
}
void Insere(No *no, char *palavra)
{
	int i;
	int index;
	No *aux, *aux2;
	aux = Fim(no, palavra);
	if (aux != NULL && aux->tipo != 'P')
	{
		aux->tipo = 'P';
	}
	else if (aux != NULL && aux->tipo == 'P')
	{
		return;
	}
	else
	{
		aux2 = no;
		for (i = 0; i < strlen(palavra); i++)
	    	{
			//como codigo do alfabeto começa em a, subtraimos 97
			index = (int)palavra[i] - 97;
			if ( aux2->letras[index] != NULL)
			{
				aux2 = aux2->letras[index];
			} 
			else
			{
				aux = Cria();
				aux2->letras[index] = aux;
				aux->pai = aux2;
				aux2->rep=0;
				aux2 = aux;
			}
		}
		aux2->tipo = 'P';
	}
}
void Remover(No *no)
{
	int i,contador=0;
	No *aux;
	if (no == NULL)
	{
		return;
	}
	aux = no->pai;
	for (i=0; i<26; i++)
	{
		if (no->letras[i])
		{
			contador ++;
			Remover (no->letras[i]);
			
		}
	}
	
	free(no);
	no =NULL;
}
void Imprime(No *no, Palavras *dicionario, int n)
{
	int i=0;
	No *aux; 
	while (i < n)
	{
		no = Fim(no,dicionario[i].c);
		printf("%d\n",no->rep);
		i++;
	}
}
