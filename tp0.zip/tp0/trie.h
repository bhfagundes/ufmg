struct no 
{
	int rep;
	char tipo;
	struct no *letras[26]; 
	struct no *pai;
};
typedef struct no No;
/*
rep: indica numero de repeticoes da palavra no texto
tipo: I indica que nao e fim de palavra e P indica fim
letras: cria um vetor em cada no para as possiveis letras
pai: apontador para o no pai
*/
typedef struct palavra
{
	char c[17];
}Palavras;
/*
estrutura para armazenar palavras.
Conforme enunciano o tamanho maximo era 15 caracteres
como precisamos alocar o carater \0, utilizei 16 caracteres
*/
No* Cria();
/*Informacoes importantes da funcao
Nome: Cria
Objetivo: Alocar a memoria para um dado no
Saida:Retorna uma estrutura no alocada
*/
No* Fim(No *no, char *palavra);
/*
Nome: Fim
Objetivo: Retornar o final de uma palavra
Saida:Retorna endereço da palavra ou NULL
obs: para calcular o index, considerei que o codigo 
     asc do caracter 'a' e 97. Assim subtraio 97 do 
     codigo do char de modo que o caracter 'a' seja
     indexado na posicao 0 do vetor
*/
void Insere(No *no, char *palavra);
/*
Nome: Insere
Objetivo: Inserer uma palavra na trie
Saida:Apenas insere a palavra caso necessario
obs: para calcular o index, considerei que o codigo 
     asc do caracter 'a' e 97. Assim subtraio 97 do 
     codigo do char de modo que o caracter 'a' seja
     indexado na posicao 0 do vetor. A funcao acima
     e chamada para verificar se a palavra existe e
     caso ja exista o prefixo da palavra, retorna o
     endereco do mesmo para que seja trocado apenas
     o tipo
*/
void Remover(No *no);
/*
Nome: Remover
Objetivo: Desalocar a memoria alocada dinamicamente
Saida:Apenas desaloca a memoria
obs: A funcao Remover, faz uma varredura nos filhos
     e casa os filhos sejam todos null e desalocada
     a memoria gasta nesse no e a funcao e chamada
     recusrivamente para o no pai
*/
void Imprime(No *no, Palavras *dicionario, int n);
/*
Nome: Imprime
Objetivo: Imprime o numero de repeticos de palavras
Saida:Printa na tela as repeticoes
obs: A funcao realiza n iteracoes, onde n e o numero
     de palavras no dicionario, para que seja exibida
     o numero de repeticoes de cada palavra.
*/
