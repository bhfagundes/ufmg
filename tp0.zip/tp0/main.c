#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "trie.h"

int main()
{
	int m;
	int n;
	Palavras *dicionario;
	Palavras *texto;
	int j =0;
	scanf("%d", &n);	
	dicionario = malloc(n * sizeof(Palavras));
	while (j < n)
	{
		scanf("%s", dicionario[j].c);		
		j++;
	}	
	scanf("%d", &m);
	texto = malloc(m * sizeof(Palavras));
	j=0;
	while (j < m)
	{
		scanf("%s", texto[j].c);		
		j++;
	}
	j=0;
	No *no = Cria();
	No *aux;
	int k=0;
	while( j < n)
	{
		Insere(no,dicionario[j].c);	
		j++;	
	}
	j=0;
    	while( j < m)
	{
		aux = Fim(no,texto[j].c);
		if (aux!= NULL)
		{
			aux->rep++;
			
		}	
		j++;	
	}
    	j=0;
	while( j < n)
	{
		aux = Fim(no,dicionario[j].c);
		if (aux!= NULL)
		{
			printf("%d ",aux->rep); 
		}	
		j++;	
	}
	Remover(no);	
	free(dicionario);
	free(texto);
	return 0;
}
